$letter = $env:dataPartitionLetter
$volumeList = Get-WmiObject -class win32_volume
$volumeLength = $volumeList.Length

if ($letter.Length -ne 1) {
       $clpmsg = "start.bat: Drive Letter is wrong. Please set it as one character."
       clplogcmd -m $clpmsg -l ERR
       exit 1
}

$letter = $letter.ToUpper()
$letter += ":"
$guid = ""

$findFlag = 0
for ($i = 0; $i -lt $volumeLength; $i++) {
    if ($letter -eq $volumeList[$i].DriveLetter) {
        $guid = $volumeList[$i].DeviceID
        $findFlag = 1
        break
    }
}

if ($findFlag -ne 1) {
       $clpmsg = "start.bat: Drive Letter is wrong. It does not exist."
       clplogcmd -m $clpmsg -l ERR
       exit 1
}

mountvol $letter /p
mountvol $letter $guid

exit 0